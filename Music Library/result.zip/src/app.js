import { page, render } from "../api/lib.js";
import { showHome } from "./views/home.js";
import { showCatalog } from "./views/catalog.js";
import { showLogin } from "./views/login.js";
import { showRegister } from "./views/register.js";
import { showDetails } from "./views/detail.js";
import { showCreate } from "./views/create.js";
import { showEdit } from "./views/edit.js";
import { getUserData } from "./util.js";
import { updateNav } from "./views/nav.js";

const main = document.querySelector('main');

page(decorateContext);
page('/', showHome);
page('/catalog', showCatalog);
page('/catalog/:id', showDetails);
page('/edit/:id',showEdit);
page('/create', showCreate);
page('/login', showLogin);
page('/register', showRegister);

updateNav();
page.start();

function decorateContext(ctx, next) { //middlewear function
    ctx.render = renderMain;
    ctx.updateNav = updateNav;

    const user = getUserData();
    if(user){
        ctx.user = user;
    }
    next() //в случай че ф-ята е асинхронна за да продължи нататък
}
function renderMain(content) {
    render(content, main);
}
